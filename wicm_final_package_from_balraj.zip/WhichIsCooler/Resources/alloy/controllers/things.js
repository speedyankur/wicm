function Controller() {
    require("alloy/controllers/BaseController").apply(this, Array.prototype.slice.call(arguments));
    this.__controllerPath = "things";
    arguments[0] ? arguments[0]["__parentSymbol"] : null;
    arguments[0] ? arguments[0]["$model"] : null;
    arguments[0] ? arguments[0]["__itemTemplate"] : null;
    var $ = this;
    var exports = {};
    $.__views.coolest = Ti.UI.createView({
        id: "coolest",
        layout: "vertical",
        bottom: "45"
    });
    $.__views.coolest && $.addTopLevelView($.__views.coolest);
    $.__views.__alloyId109 = Ti.UI.createView({
        top: "1",
        height: "50",
        backgroundColor: "#E9E9E9",
        id: "__alloyId109"
    });
    $.__views.coolest.add($.__views.__alloyId109);
    $.__views.__alloyId110 = Ti.UI.createTextField({
        color: "#808080",
        autocorrect: "false",
        hintText: "Search",
        left: "10",
        height: "35",
        top: "7",
        bottom: "7",
        right: "90",
        borderRadius: "30",
        backgroundColor: "#FFF",
        id: "__alloyId110"
    });
    $.__views.__alloyId109.add($.__views.__alloyId110);
    $.__views.searchButton = Ti.UI.createButton({
        backgroundImage: "/images/btn_search.png",
        width: "60",
        height: "30",
        top: "10",
        bottom: "10",
        right: "10",
        id: "searchButton"
    });
    $.__views.__alloyId109.add($.__views.searchButton);
    $.__views.scrollView = Ti.UI.createScrollView({
        id: "scrollView",
        layout: "horizontal"
    });
    $.__views.coolest.add($.__views.scrollView);
    $.__views.col1 = Ti.UI.createView({
        id: "col1",
        width: "45%",
        layout: "vertical"
    });
    $.__views.scrollView.add($.__views.col1);
    $.__views.col2 = Ti.UI.createView({
        id: "col2",
        width: "55%",
        layout: "vertical"
    });
    $.__views.scrollView.add($.__views.col2);
    exports.destroy = function() {};
    _.extend($, $.__views);
    if (Alloy.Globals.APIKey) {
        Alloy.Globals.loading.show("Loading, Please wait..", true);
        var xhr = Ti.Network.createHTTPClient();
        xhr.open("GET", Alloy.Globals.serverPath + "/api/things/mine");
        xhr.setRequestHeader("Authorization", "Token token=" + Alloy.Globals.APIKey);
        xhr.send();
        xhr.onload = function() {
            var myThings = JSON.parse(this.responseText);
            _.each(myThings.result, function(element, index) {
                var score = parseFloat(element.cool_score).toFixed(2);
                var args = {
                    score: score,
                    image: element.url
                };
                0 == index % 2 ? $.col1.add(Alloy.createController("thing", args).getView()) : $.col2.add(Alloy.createController("thing", args).getView());
            });
            Alloy.Globals.loading.hide();
        };
        xhr.onerror = function() {
            Ti.API.info("got some error");
            Alloy.Globals.loading.hide();
        };
    } else alert("Please Login First");
    _.extend($, exports);
}

var Alloy = require("alloy"), Backbone = Alloy.Backbone, _ = Alloy._;

module.exports = Controller;