function Controller() {
    function goToLogin() {
        var controller = Alloy.createController("login");
        var win = controller.getView();
        win.open({
            activityEnterAnimation: Ti.App.Android.R.anim.slide_in_right
        });
    }
    function closingWindowAnimationforAndroid() {
        $.post.close({
            activityExitAnimation: Ti.Android.R.anim.slide_out_right
        });
    }
    function handleSwipeEvent(e) {
        "right" == e.direction ? closingWindowAnimationforAndroid() : "left" == e.direction && goToLogin();
    }
    function onClose() {
        Ti.Gesture.removeEventListener("orientationchange", applyOrientiation);
    }
    function applyOrientiation() {
        var orientName = "portrait", lastOrientName = "landscape";
        if (Ti.Gesture.orientation == Ti.UI.LANDSCAPE_LEFT || Ti.Gesture.orientation == Ti.UI.LANDSCAPE_RIGHT) {
            orientName = "landscape";
            lastOrientName = "portrait";
        }
        if ("landscape" == orientName) {
            $.portrait.hide();
            $.landscape.show();
        } else {
            $.portrait.show();
            $.landscape.hide();
        }
    }
    require("alloy/controllers/BaseController").apply(this, Array.prototype.slice.call(arguments));
    this.__controllerPath = "post";
    arguments[0] ? arguments[0]["__parentSymbol"] : null;
    arguments[0] ? arguments[0]["$model"] : null;
    arguments[0] ? arguments[0]["__itemTemplate"] : null;
    var $ = this;
    var exports = {};
    var __defers = {};
    $.__views.win = Ti.UI.createWindow({
        backgroundColor: "#fff",
        modal: false,
        navBarHidden: true,
        id: "win"
    });
    $.__views.win && $.addTopLevelView($.__views.win);
    handleSwipeEvent ? $.__views.win.addEventListener("swipe", handleSwipeEvent) : __defers["$.__views.win!swipe!handleSwipeEvent"] = true;
    onClose ? $.__views.win.addEventListener("close", onClose) : __defers["$.__views.win!close!onClose"] = true;
    closingWindowAnimationforAndroid ? $.__views.win.addEventListener("android:back", closingWindowAnimationforAndroid) : __defers["$.__views.win!android:back!closingWindowAnimationforAndroid"] = true;
    $.__views.portrait = Ti.UI.createView({
        height: Ti.UI.FILL,
        visible: "false",
        id: "portrait"
    });
    $.__views.win.add($.__views.portrait);
    $.__views.logo = Ti.UI.createImageView({
        width: "276",
        height: "38",
        image: "/images/logo.png",
        id: "logo",
        top: "10"
    });
    $.__views.portrait.add($.__views.logo);
    $.__views.__alloyId89 = Ti.UI.createLabel({
        width: Ti.UI.FILL,
        textAlign: "center",
        height: Ti.UI.SIZE,
        color: "#808080",
        font: {
            fontSize: "20",
            fontFamily: "Helvetica Neue"
        },
        text: "Post cool things to see\nwhat others think.",
        top: "60",
        id: "__alloyId89"
    });
    $.__views.portrait.add($.__views.__alloyId89);
    $.__views.shareIcon = Ti.UI.createImageView({
        image: "/images/post_share_icon.png",
        width: "204",
        height: "270",
        top: "130",
        id: "shareIcon"
    });
    $.__views.portrait.add($.__views.shareIcon);
    $.__views.__alloyId90 = Ti.UI.createButton({
        color: "#fff",
        font: {
            fontSize: "15",
            fontFamily: "Helvetica Neue"
        },
        borderRadius: "8",
        backgroundImage: "none",
        height: "46",
        backgroundColor: "#30D1F4",
        backgroundSelectedColor: "#000",
        title: "Continue",
        width: "230",
        bottom: "20",
        id: "__alloyId90"
    });
    $.__views.portrait.add($.__views.__alloyId90);
    try {
        $.__views.__alloyId90.addEventListener("touchstart", Alloy.Globals.buttonFocused);
    } catch (e) {
        __defers["$.__views.__alloyId90!touchstart!Alloy.Globals.buttonFocused"] = true;
    }
    try {
        $.__views.__alloyId90.addEventListener("touchend", Alloy.Globals.buttonBlurred);
    } catch (e) {
        __defers["$.__views.__alloyId90!touchend!Alloy.Globals.buttonBlurred"] = true;
    }
    goToLogin ? $.__views.__alloyId90.addEventListener("click", goToLogin) : __defers["$.__views.__alloyId90!click!goToLogin"] = true;
    $.__views.landscape = Ti.UI.createView({
        visible: "false",
        id: "landscape",
        layout: "horizontal"
    });
    $.__views.win.add($.__views.landscape);
    $.__views.column1 = Ti.UI.createView({
        width: "55%",
        id: "column1"
    });
    $.__views.landscape.add($.__views.column1);
    $.__views.logo = Ti.UI.createImageView({
        width: "260",
        height: "35",
        image: "/images/logo.png",
        id: "logo",
        top: "40"
    });
    $.__views.column1.add($.__views.logo);
    $.__views.__alloyId91 = Ti.UI.createLabel({
        width: Ti.UI.FILL,
        textAlign: "center",
        height: Ti.UI.SIZE,
        color: "#808080",
        font: {
            fontSize: "20",
            fontFamily: "Helvetica Neue"
        },
        text: "Post cool things and\n what others think.",
        top: "110",
        id: "__alloyId91"
    });
    $.__views.column1.add($.__views.__alloyId91);
    $.__views.__alloyId92 = Ti.UI.createButton({
        color: "#fff",
        font: {
            fontSize: "15",
            fontFamily: "Helvetica Neue"
        },
        borderRadius: "8",
        backgroundImage: "none",
        height: "46",
        backgroundColor: "#30D1F4",
        backgroundSelectedColor: "#000",
        title: "Continue",
        width: "230",
        bottom: "20",
        id: "__alloyId92"
    });
    $.__views.column1.add($.__views.__alloyId92);
    try {
        $.__views.__alloyId92.addEventListener("touchstart", Alloy.Globals.buttonFocused);
    } catch (e) {
        __defers["$.__views.__alloyId92!touchstart!Alloy.Globals.buttonFocused"] = true;
    }
    try {
        $.__views.__alloyId92.addEventListener("touchend", Alloy.Globals.buttonBlurred);
    } catch (e) {
        __defers["$.__views.__alloyId92!touchend!Alloy.Globals.buttonBlurred"] = true;
    }
    goToLogin ? $.__views.__alloyId92.addEventListener("click", goToLogin) : __defers["$.__views.__alloyId92!click!goToLogin"] = true;
    $.__views.column2 = Ti.UI.createView({
        width: "45%",
        id: "column2"
    });
    $.__views.landscape.add($.__views.column2);
    $.__views.shareIcon = Ti.UI.createImageView({
        image: "/images/post_share_icon.png",
        width: "204",
        height: "270",
        id: "shareIcon",
        top: "10"
    });
    $.__views.column2.add($.__views.shareIcon);
    exports.destroy = function() {};
    _.extend($, $.__views);
    var iOS7 = Alloy.Globals.isiOS7Plus();
    $.win.top = iOS7 ? 20 : 0;
    Ti.UI.setBackgroundColor("#FFF");
    Ti.Gesture.addEventListener("orientationchange", applyOrientiation);
    setTimeout(function() {
        applyOrientiation();
    }, 300);
    __defers["$.__views.win!swipe!handleSwipeEvent"] && $.__views.win.addEventListener("swipe", handleSwipeEvent);
    __defers["$.__views.win!close!onClose"] && $.__views.win.addEventListener("close", onClose);
    __defers["$.__views.win!android:back!closingWindowAnimationforAndroid"] && $.__views.win.addEventListener("android:back", closingWindowAnimationforAndroid);
    __defers["$.__views.__alloyId90!touchstart!Alloy.Globals.buttonFocused"] && $.__views.__alloyId90.addEventListener("touchstart", Alloy.Globals.buttonFocused);
    __defers["$.__views.__alloyId90!touchend!Alloy.Globals.buttonBlurred"] && $.__views.__alloyId90.addEventListener("touchend", Alloy.Globals.buttonBlurred);
    __defers["$.__views.__alloyId90!click!goToLogin"] && $.__views.__alloyId90.addEventListener("click", goToLogin);
    __defers["$.__views.__alloyId92!touchstart!Alloy.Globals.buttonFocused"] && $.__views.__alloyId92.addEventListener("touchstart", Alloy.Globals.buttonFocused);
    __defers["$.__views.__alloyId92!touchend!Alloy.Globals.buttonBlurred"] && $.__views.__alloyId92.addEventListener("touchend", Alloy.Globals.buttonBlurred);
    __defers["$.__views.__alloyId92!click!goToLogin"] && $.__views.__alloyId92.addEventListener("click", goToLogin);
    _.extend($, exports);
}

var Alloy = require("alloy"), Backbone = Alloy.Backbone, _ = Alloy._;

module.exports = Controller;