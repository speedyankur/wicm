function Controller() {
    function onTouchmove(e) {
        e.cancelBubble = true;
    }
    require("alloy/controllers/BaseController").apply(this, Array.prototype.slice.call(arguments));
    this.__controllerPath = "wic";
    arguments[0] ? arguments[0]["__parentSymbol"] : null;
    arguments[0] ? arguments[0]["$model"] : null;
    arguments[0] ? arguments[0]["__itemTemplate"] : null;
    var $ = this;
    var exports = {};
    var __defers = {};
    $.__views.wic = Ti.UI.createView({
        apiName: "Ti.UI.View",
        id: "wic",
        bottom: "44",
        classes: []
    });
    $.__views.wic && $.addTopLevelView($.__views.wic);
    onTouchmove ? $.__views.wic.addEventListener("touchmove", onTouchmove) : __defers["$.__views.wic!touchmove!onTouchmove"] = true;
    var __alloyId124 = [];
    $.__views.__alloyId125 = Alloy.createController("wicMatch", {
        apiName: "Alloy.Require",
        id: "__alloyId125",
        classes: []
    });
    __alloyId124.push($.__views.__alloyId125.getViewEx({
        recurse: true
    }));
    $.__views.scrollableView = Ti.UI.createScrollableView({
        views: __alloyId124,
        apiName: "Ti.UI.ScrollableView",
        id: "scrollableView",
        showPagingControl: "false",
        classes: []
    });
    $.__views.wic.add($.__views.scrollableView);
    exports.destroy = function() {};
    _.extend($, $.__views);
    Alloy.Globals.fetchNextMatch = function() {
        var controller = Alloy.createController("wicMatch");
        var matchView = controller.getView();
        $.scrollableView.addView(matchView);
        $.scrollableView.scrollToView(matchView);
    };
    Alloy.Globals.removeCurrentMatch = function() {
        Ti.API.info("total views before--" + $.scrollableView.views.length);
        $.scrollableView.removeView($.scrollableView.views.length - 1);
        Ti.API.info("total views after--" + $.scrollableView.views.length);
    };
    __defers["$.__views.wic!touchmove!onTouchmove"] && $.__views.wic.addEventListener("touchmove", onTouchmove);
    _.extend($, exports);
}

var Alloy = require("alloy"), Backbone = Alloy.Backbone, _ = Alloy._;

module.exports = Controller;