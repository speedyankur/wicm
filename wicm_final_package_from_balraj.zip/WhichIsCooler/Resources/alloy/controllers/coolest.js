function Controller() {
    require("alloy/controllers/BaseController").apply(this, Array.prototype.slice.call(arguments));
    this.__controllerPath = "coolest";
    arguments[0] ? arguments[0]["__parentSymbol"] : null;
    arguments[0] ? arguments[0]["$model"] : null;
    arguments[0] ? arguments[0]["__itemTemplate"] : null;
    var $ = this;
    var exports = {};
    $.things = Alloy.createCollection("coolestThing");
    $.__views.coolest = Ti.UI.createView({
        id: "coolest",
        layout: "vertical",
        bottom: "45"
    });
    $.__views.coolest && $.addTopLevelView($.__views.coolest);
    $.__views.__alloyId16 = Ti.UI.createView({
        top: "1",
        height: "50",
        backgroundColor: "#E9E9E9",
        id: "__alloyId16"
    });
    $.__views.coolest.add($.__views.__alloyId16);
    $.__views.__alloyId17 = Ti.UI.createTextField({
        color: "#808080",
        autocorrect: "false",
        hintText: "Search",
        left: "10",
        height: "35",
        top: "7",
        bottom: "7",
        right: "90",
        borderRadius: "30",
        backgroundColor: "#FFF",
        id: "__alloyId17"
    });
    $.__views.__alloyId16.add($.__views.__alloyId17);
    $.__views.searchButton = Ti.UI.createButton({
        backgroundImage: "/images/btn_search.png",
        width: "60",
        height: "30",
        top: "10",
        bottom: "10",
        right: "10",
        id: "searchButton"
    });
    $.__views.__alloyId16.add($.__views.searchButton);
    $.__views.scrollView = Ti.UI.createScrollView({
        id: "scrollView",
        layout: "horizontal"
    });
    $.__views.coolest.add($.__views.scrollView);
    $.__views.col1 = Ti.UI.createView({
        id: "col1",
        width: "45%",
        layout: "vertical"
    });
    $.__views.scrollView.add($.__views.col1);
    $.__views.col2 = Ti.UI.createView({
        id: "col2",
        width: "55%",
        layout: "vertical"
    });
    $.__views.scrollView.add($.__views.col2);
    exports.destroy = function() {};
    _.extend($, $.__views);
    var things = $.things;
    Alloy.Globals.loading.show("Loading, Please wait..", true);
    things.fetch({
        success: function(collection) {
            Alloy.Globals.loading.hide();
            _.each(collection.models, function(element, index) {
                var score = parseFloat(element.attributes["cool_score"]).toFixed(2);
                var args = {
                    score: score,
                    image: element.attributes["url"]
                };
                0 == index % 2 ? $.col1.add(Alloy.createController("thing", args).getView()) : $.col2.add(Alloy.createController("thing", args).getView());
            });
        },
        error: function() {
            Alloy.Globals.loading.hide();
            alert("Network not avaiable, please try again later");
        }
    });
    _.extend($, exports);
}

var Alloy = require("alloy"), Backbone = Alloy.Backbone, _ = Alloy._;

module.exports = Controller;