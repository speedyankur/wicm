module.exports = {
    dependencies: {
        "ds.slideMenu": "0.1",
        "nl.fokkezb.cachedImageView": "1.3",
        "nl.fokkezb.loading": "1.6"
    }
};