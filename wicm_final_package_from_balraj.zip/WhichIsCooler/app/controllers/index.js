Alloy.Globals.navgroup = $.navgroup;

$.index.open();
