function goToUV(){
	Ti.Platform.openURL("http://wic.uservoice.com");
}
