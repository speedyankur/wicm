var args = arguments[0] || {};
$.thingImage.image = args.image;
$.thingScore.text = args.score || '';
