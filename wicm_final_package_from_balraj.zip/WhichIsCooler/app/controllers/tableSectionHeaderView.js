var args = arguments[0] || {};
$.label.text = args.text|| '';