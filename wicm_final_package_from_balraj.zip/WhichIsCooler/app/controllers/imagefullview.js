var args = arguments[0] || {};
$.fullImage.image = args.image;


function closeFullView() {
	$.imageFullview.close();
}