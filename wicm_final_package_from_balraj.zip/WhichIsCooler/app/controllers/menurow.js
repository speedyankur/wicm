var args = arguments[0] || {};
//$.icon.image = args.image;
$.title.text = args.title || '';
$.row.customView = args.customView || '';
$.row.headerTitle = args.title || '';